package Wetterdienst;

public interface Observierer
{
    public void update();
}
