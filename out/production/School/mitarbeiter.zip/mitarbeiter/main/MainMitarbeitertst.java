package main;

import mitarbeiter.Malocher;
import mitarbeiter.Mitarbeiter;

public class MainMitarbeitertst
{
	public static void main(String[] args) {
		Mitarbeiter ab = new Mitarbeiter(11, "Rudolf");
		ab.setId(12);
		ab.getId();
		ab.setName("Sander");
		System.out.println(ab.toString());

		Malocher mal = new Malocher(13, "Rudi", 450.00);
	}
}
