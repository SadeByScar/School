public interface IQuackVerhalten
{
    public void quacken();
}
