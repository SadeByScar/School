public class NormalesQuacken implements IQuackVerhalten
{
    @Override
    public void quacken() {
        System.out.println("Quack!");
    }
}
