public class StummesQuacken implements IQuackVerhalten
{
    @Override
    public void quacken() {
        System.out.println("...");
    }
}
