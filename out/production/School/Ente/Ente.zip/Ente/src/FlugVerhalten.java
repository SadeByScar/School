public abstract class FlugVerhalten
{
    public abstract void fliegen();
}
