public class Stockente extends Ente
{
    public Stockente(IQuackVerhalten qv, FlugVerhalten fv)
    {
        super(qv, fv);
    }
}
