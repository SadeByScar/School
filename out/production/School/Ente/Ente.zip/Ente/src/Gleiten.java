public class Gleiten extends FlugVerhalten
{
    @Override
    public void fliegen() {
        System.out.println("Gleiten");
    }
}
