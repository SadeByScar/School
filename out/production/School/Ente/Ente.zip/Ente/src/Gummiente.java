public class Gummiente extends Ente
{
    public Gummiente(IQuackVerhalten qv, FlugVerhalten fv)
    {
        super(qv, fv);
    }
}
