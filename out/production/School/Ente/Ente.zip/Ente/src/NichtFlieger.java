public class NichtFlieger extends FlugVerhalten
{
    @Override
    public void fliegen() {
        System.out.println("Geht nicht");
    }
}
