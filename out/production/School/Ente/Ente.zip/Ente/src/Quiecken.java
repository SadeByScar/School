public class Quiecken implements IQuackVerhalten
{
    @Override
    public void quacken() {
        System.out.println("Quieck");
    }
}
